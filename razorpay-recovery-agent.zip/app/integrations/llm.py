"""Optional LLM-assisted diagnosis and recovery-decision functions.

Both entry points here are only invoked when their respective feature
flags AND the configured provider's credentials are set, so the pipeline
still runs fully deterministically offline for fast iteration/demo
without needing any LLM access at all -- and both degrade to a safe,
logged default on any failure (bad key, network error, malformed
response) rather than raising.

Two providers are supported, selected by settings.LLM_PROVIDER:
- "anthropic" (default): the Claude API. Needs ANTHROPIC_API_KEY and
  billing set up on the account.
- "gemini": Google's hosted Gemini API, calling a Gemma model. Needs
  GEMINI_API_KEY (free via https://aistudio.google.com/apikey, no
  billing required to start).

Both go through _call_llm() below, so llm_diagnose and
llm_recommend_action don't know or care which one answered -- same
prompts, same bounded JSON schemas, same fallback behavior either way.
"""
import json
import random
import threading
import time
from typing import Optional

from app.config import settings
from app.models import AgentRecommendation, Signal, RootCause, Diagnosis

_ROOT_CAUSE_VALUES = [c.value for c in RootCause]


def _llm_configured() -> bool:
    if settings.LLM_PROVIDER == "gemini":
        return bool(settings.GEMINI_API_KEY)
    return bool(settings.ANTHROPIC_API_KEY)


def _extract_json(text: str) -> dict:
    """Smaller/open models are more prone than Claude to wrapping JSON in
    a markdown code fence despite being told not to -- strip one off if
    present, then parse. Raises (like a bare json.loads would) on
    anything that still isn't valid JSON, which callers already catch."""
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
        text = text.strip()
    return json.loads(text)


# Whether this Gemma/Gemini model honors generationConfig.thinkingConfig
# (see _gemini_generate). None = not yet discovered, True/False once a real
# call has told us. Cached process-wide so the discovery cost is paid at
# most once per run, not once per signal.
_GEMINI_MINIMAL_THINKING_SUPPORTED = None

# Transient upstream failures worth one retry rather than an immediate
# fallback to the deterministic default: rate limiting (very reachable on a
# free tier once calls run concurrently) and upstream unavailability.
_RETRYABLE_HTTP_CODES = {429, 500, 502, 503, 504}
_MAX_TRANSIENT_RETRIES = 4

# --- Adaptive client-side rate limiting -------------------------------------
#
# Free-tier keys rate-limit well before a laptop runs out of threads: a
# 120-case batch (70 consultations at 6-way concurrency) came back 46% HTTP
# 429, so nearly half the signals silently fell back to the deterministic
# default instead of getting a real model opinion.
#
# Google publishes per-account limits in AI Studio rather than one fixed
# number per model, and a hard-coded RPM guess would be wrong for anyone on a
# different tier. So rather than guess, the client DISCOVERS the usable rate:
# requests are spaced by a shared minimum interval, every 429 widens that
# interval for all workers, and sustained success narrows it again. A run
# self-tunes to whatever the key actually allows, and an upgraded key speeds
# back up on its own.
_rate_lock = threading.Lock()
_min_request_interval = 1.0      # seconds between requests; adapts at runtime
# Starts deliberately conservative rather than fast: converging DOWN from a
# safe rate costs a few seconds on a generous key, while converging UP from an
# aggressive one costs real 429s, and a 429 that exhausts its retries becomes a
# signal that never got a model opinion at all.
_INTERVAL_FLOOR = 0.2
_INTERVAL_CEILING = 12.0
_INTERVAL_WIDEN_FACTOR = 1.8     # on a 429, back off hard
_INTERVAL_NARROW_FACTOR = 0.97   # on success, creep back down
_last_request_at = 0.0


def _throttle() -> None:
    """Serialises request starts so concurrent workers stay under the rate
    limit. The sleep deliberately happens while holding the lock: each caller
    waits its turn, which is what spaces the requests out."""
    global _last_request_at
    with _rate_lock:
        wait = _min_request_interval - (time.monotonic() - _last_request_at)
        if wait > 0:
            time.sleep(wait)
        _last_request_at = time.monotonic()


def _widen_interval() -> None:
    global _min_request_interval
    with _rate_lock:
        _min_request_interval = min(
            _min_request_interval * _INTERVAL_WIDEN_FACTOR, _INTERVAL_CEILING
        )


def _narrow_interval() -> None:
    global _min_request_interval
    with _rate_lock:
        _min_request_interval = max(
            _min_request_interval * _INTERVAL_NARROW_FACTOR, _INTERVAL_FLOOR
        )


def current_request_interval() -> float:
    """The interval the client has settled on for this run (tests/diagnostics)."""
    with _rate_lock:
        return _min_request_interval


def _retry_delay(exc, attempt: int) -> float:
    """Prefers the server's own Retry-After over a guess -- it knows when the
    window reopens and we don't."""
    headers = getattr(exc, "headers", None)
    if headers is not None:
        try:
            return min(float(headers.get("Retry-After")), _INTERVAL_CEILING * 2)
        except (TypeError, ValueError):
            pass
    return min(1.5 * (2 ** attempt), _INTERVAL_CEILING * 2) + random.uniform(0, 0.5)


def _gemini_payload(prompt: str, max_tokens: int, minimal_thinking: bool) -> bytes:
    """Builds one generateContent request body.

    `minimal_thinking` asks Gemma to skip its internal reasoning pass. That
    pass is the single biggest cost in this system: for a bounded
    three-way classification, a trivial prompt was measured generating 169
    thinking tokens to produce a 21-token answer -- ~89% of everything
    generated, and generation is sequential, so it dominates wall-clock
    time (~5.4s/call). Suppressing it is worth several-fold speedup, but
    the controls are unreliable on Gemma specifically (thinkingBudget is
    rejected outright; includeThoughts is silently ignored), so this is
    attempted optimistically and abandoned permanently the moment the API
    rejects it -- see _gemini_generate.

    maxOutputTokens stays padded regardless: if thinking is NOT suppressed,
    a tight budget gets consumed mid-thought and returns no usable answer
    at all (finishReason=MAX_TOKENS with only a "thought" part).
    """
    generation_config = {"maxOutputTokens": max(max_tokens, 2048), "temperature": 0.2}
    if minimal_thinking:
        generation_config["thinkingConfig"] = {"thinkingLevel": "MINIMAL"}
    return json.dumps(
        {
            "contents": [{"role": "user", "parts": [{"text": prompt}]}],
            "generationConfig": generation_config,
        }
    ).encode()


def _gemini_post(payload: bytes, timeout: int = 30) -> dict:
    import urllib.request

    url = (
        f"https://generativelanguage.googleapis.com/v1beta/models/"
        f"{settings.GEMINI_MODEL}:generateContent?key={settings.GEMINI_API_KEY}"
    )
    req = urllib.request.Request(
        url, data=payload, headers={"Content-Type": "application/json"}, method="POST"
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read())


def _gemini_post_with_retry(payload: bytes) -> dict:
    """One retry pass over transient upstream failures. Concurrency (see
    app/engine/pipeline.py's prefetch) makes free-tier rate limiting a
    realistic occurrence rather than a theoretical one, and a 429 that
    silently degrades to the deterministic default is a worse outcome than
    waiting a second and asking again."""
    import urllib.error

    for attempt in range(_MAX_TRANSIENT_RETRIES + 1):
        _throttle()
        try:
            response = _gemini_post(payload)
        except urllib.error.HTTPError as exc:
            if exc.code == 429:
                # Slow every worker down, not just this one: the limit is
                # per-key, so one thread hitting it means all of them are
                # going too fast.
                _widen_interval()
            if exc.code not in _RETRYABLE_HTTP_CODES or attempt == _MAX_TRANSIENT_RETRIES:
                raise
            time.sleep(_retry_delay(exc, attempt))
        else:
            _narrow_interval()
            return response


def _gemini_generate(prompt: str, max_tokens: int) -> str:
    """Calls Gemma via the hosted Gemini API, preferring the no-thinking
    fast path and permanently falling back if this model rejects it."""
    import urllib.error

    global _GEMINI_MINIMAL_THINKING_SUPPORTED
    try_minimal = _GEMINI_MINIMAL_THINKING_SUPPORTED is not False

    try:
        data = _gemini_post_with_retry(_gemini_payload(prompt, max_tokens, try_minimal))
        if try_minimal:
            _GEMINI_MINIMAL_THINKING_SUPPORTED = True
    except urllib.error.HTTPError as exc:
        # A 400 on the optimistic attempt means this model doesn't accept
        # thinkingConfig -- remember that and never pay for the rejection
        # again, then immediately retry the same prompt without it so the
        # caller never sees a failure it didn't need to see.
        if try_minimal and exc.code == 400:
            _GEMINI_MINIMAL_THINKING_SUPPORTED = False
            data = _gemini_post_with_retry(_gemini_payload(prompt, max_tokens, False))
        else:
            raise

    # Skip any part marked "thought": true -- when thinking isn't
    # suppressed, the model's internal scratchpad comes back as its own
    # part alongside the real answer, and joining them would feed the
    # scratchpad into the JSON parser.
    parts = data["candidates"][0]["content"]["parts"]
    answer = "".join(p.get("text", "") for p in parts if not p.get("thought"))
    if not answer:
        candidate = data["candidates"][0]
        raise ValueError(
            f"Gemini/Gemma response had no non-thought text (finishReason="
            f"{candidate.get('finishReason')!r}, thoughtsTokenCount="
            f"{data.get('usageMetadata', {}).get('thoughtsTokenCount')!r}); "
            f"try a higher max_tokens"
        )
    return answer


def _call_llm(prompt: str, max_tokens: int = 200) -> str:
    """Sends `prompt` to whichever provider is configured and returns the
    raw response text. Raises on any failure -- every caller wraps this
    in a try/except and falls back to a safe deterministic default,
    exactly the same way regardless of provider."""
    if settings.LLM_PROVIDER == "gemini":
        return _gemini_generate(prompt, max_tokens)

    import anthropic

    client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
    resp = client.messages.create(
        model="claude-3-5-haiku-latest",
        max_tokens=max_tokens,
        messages=[{"role": "user", "content": prompt}],
    )
    return resp.content[0].text


_PROMPT_TEMPLATE = """You are a revenue-recovery diagnosis assistant for a payments company.
Given a signal about at-risk revenue, pick the single best root cause from this list:
{causes}

Signal type: {signal_type}
Amount: {amount} {currency}
Metadata: {metadata}

Respond with strict JSON, and nothing else, no markdown formatting: {{"root_cause": "<one of the list>", "confidence": <0-1 float>, "reasoning": "<one sentence>"}}
"""


def llm_diagnose(signal: Signal) -> Optional[Diagnosis]:
    if not settings.USE_LLM_DIAGNOSIS or not _llm_configured():
        return None
    try:
        prompt = _PROMPT_TEMPLATE.format(
            causes=", ".join(_ROOT_CAUSE_VALUES),
            signal_type=signal.type.value,
            amount=signal.amount,
            currency=signal.currency,
            metadata=json.dumps(signal.metadata, default=str),
        )
        data = _extract_json(_call_llm(prompt, max_tokens=200))
        return Diagnosis(
            signal_id=signal.id,
            root_cause=RootCause(data["root_cause"]),
            confidence=float(data["confidence"]),
            reasoning=data["reasoning"],
        )
    except Exception as exc:  # best-effort fallback, never crash the pipeline
        return Diagnosis(
            signal_id=signal.id,
            root_cause=RootCause.UNKNOWN,
            confidence=0.0,
            reasoning=f"LLM diagnosis failed: {exc}",
        )


_AGENT_ALLOWED_ACTIONS = {"proceed", "hold", "escalate"}

# Upper bound on how long the agent may postpone outreach. A deferral is
# advisory and one-directional: it can push contact later (the agent judging
# now to be a bad moment), never earlier, and never past the point where the
# signal would go stale. Anything outside this range is clamped, not obeyed.
_MAX_DEFER_HOURS = 24

_AGENT_PROMPT_TEMPLATE = """You are a bounded recovery-decision agent for a payments company's revenue-recovery system.

This specific signal has ALREADY cleared every deterministic compliance/safety guardrail (opt-outs, mandatory-escalation root causes, high-value thresholds, max-contact-attempts, cooldown, quiet hours) and is cleared to proceed with its assigned recovery playbook. Your only job is to sanity-check that call using the context below -- most of the time "proceed" is correct, but you may override it for this specific case if something in the context genuinely warrants more caution than the deterministic rules alone applied.

Signal type: {signal_type}
Amount: {amount} {currency}
Diagnosed root cause: {root_cause} (rule confidence: {diagnosis_confidence})
Assigned playbook: {playbook}
Customer's prior contact attempts on record: {prior_contact_attempts}
Customer language preference: {language_pref}
Channels already tried for this customer (attempts, and how many led to a recovery): {channels_already_tried}
Additional context: {extra_context}

Choose exactly one action:
- "proceed": go ahead with the assigned playbook.
- "hold": don't contact the customer this round (e.g. already close to the contact limit, or outreach right now seems premature for this specific case) -- explain why.
- "escalate": flag this specific case for human review even though it didn't trip an automatic escalation rule (e.g. borderline-high amount, unusually low diagnosis confidence, or something in the context looks atypical for this root cause).

If (and only if) you choose "proceed", you may also shape HOW the outreach happens:
- "channel": which channel to use, from this list and no other: {available_channels}. Default to null. The playbook's own default already adapts to the customer's language preference, so only name a channel when "Channels already tried" above gives you a concrete reason to switch -- for example a channel attempted more than once for this customer with no recovery. If that history is empty you have no evidence to justify overriding the default: return null.
- "defer_hours": an integer from 0 to {max_defer_hours}. Use 0 to send now. Use a positive number when contacting immediately looks counterproductive for this specific case and waiting is likely to do better (e.g. a bank-side failure that needs time to clear before a retry has any chance). You can only delay outreach, never bring it forward.

Respond with strict JSON, and nothing else, no markdown formatting: {{"action": "<one of proceed|hold|escalate>", "channel": "<one of {available_channels}, or null>", "defer_hours": <integer 0-{max_defer_hours}>, "confidence": <0-1 float>, "reasoning": "<one or two sentences, specific to this case, mentioning the channel/delay choice if you made one>"}}
"""


def llm_recommend_action(signal: Signal, diagnosis: Diagnosis, context: dict) -> Optional[AgentRecommendation]:
    """Asks the configured LLM to sanity-check (never expand) the
    deterministic policy engine's decision to proceed with a signal's
    assigned playbook. `context` is built by app.engine.agent._build_context
    from real state (contact history, metadata) -- nothing here is
    invented.

    Returns None only when the feature is off or unconfigured (no call
    attempted at all, matching llm_diagnose's convention). Once a call IS
    attempted, this always returns an AgentRecommendation -- on any
    failure (bad key, network error, unparseable/out-of-set response) it
    returns one with action="proceed" and `error` set, so a flaky call
    degrades to the deterministic default rather than ever crashing the
    batch or silently doing nothing."""
    if not settings.USE_AI_RECOVERY_AGENT or not _llm_configured():
        return None
    try:
        core_keys = {
            "signal_type", "amount", "currency", "root_cause",
            "diagnosis_confidence", "playbook", "prior_contact_attempts", "language_pref",
            "available_channels", "channels_already_tried",
        }
        extra = {k: v for k, v in context.items() if k not in core_keys}
        prompt = _AGENT_PROMPT_TEMPLATE.format(
            signal_type=context["signal_type"],
            amount=context["amount"],
            currency=context["currency"],
            root_cause=context["root_cause"],
            diagnosis_confidence=context["diagnosis_confidence"],
            playbook=context["playbook"],
            prior_contact_attempts=context["prior_contact_attempts"],
            language_pref=context["language_pref"],
            extra_context=json.dumps(extra, default=str),
            available_channels=", ".join(context.get("available_channels", [])) or "none",
            channels_already_tried=json.dumps(context.get("channels_already_tried", {}), default=str),
            max_defer_hours=_MAX_DEFER_HOURS,
        )
        data = _extract_json(_call_llm(prompt, max_tokens=200))
        action = data.get("action")
        if action not in _AGENT_ALLOWED_ACTIONS:
            return AgentRecommendation(
                signal_id=signal.id, action="proceed", confidence=0.0,
                reasoning=data.get("reasoning", ""),
                error=f"model returned an action outside the bounded set: {action!r}",
            )
        # Validate/clamp before anything reaches a Decision. A model answer
        # is a suggestion about HOW to act, never permission to act
        # differently: an unsupported channel falls back to the playbook's
        # own default, and a defer outside the allowed window is clamped
        # rather than honoured (a negative value could otherwise be read as
        # "contact sooner", which the agent is never allowed to ask for).
        allowed_channels = set(context.get("available_channels", []))
        channel = data.get("channel")
        if channel not in allowed_channels:
            channel = None

        try:
            defer_hours = int(data.get("defer_hours") or 0)
        except (TypeError, ValueError):
            defer_hours = 0
        defer_hours = max(0, min(defer_hours, _MAX_DEFER_HOURS))

        # Channel and delay only mean anything for an outreach that is
        # actually going to happen.
        if action != "proceed":
            channel, defer_hours = None, 0

        return AgentRecommendation(
            signal_id=signal.id,
            action=action,
            confidence=float(data.get("confidence", 0.0)),
            reasoning=data.get("reasoning", ""),
            channel=channel,
            defer_hours=defer_hours,
        )
    except Exception as exc:  # best-effort fallback, never crash the pipeline
        return AgentRecommendation(
            signal_id=signal.id, action="proceed", confidence=0.0,
            reasoning="agent call failed; defaulting to the deterministic decision",
            error=str(exc),
        )
